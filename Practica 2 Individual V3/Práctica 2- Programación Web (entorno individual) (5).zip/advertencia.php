<!DOCUMENT html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <link rel="shortcut icon" type="image/x-icon" href="img/icono.ico"/>
    <title>DISTRIB SL</title>
</head>
<body>
<h1>Advertencia</h1>
<h4>El usuario que deseas borrar tiene pedidos asociados, abortando operación...</h4>
<h5>Redirigiendo...</h5>
<meta http-equiv="refresh" content="5;url=editarusuarios.php" />
<footer>
    Distrib SL ©Todos los derechos reservados contacto@distrib.com
</footer>
</body>
</html>